import 'package:flutter/material.dart';

class NeumorphicStyledContainer extends StatelessWidget {
  final Widget child;
  final String accuracy;
  final bool geminiProcessing;
  final String healthData;
  final String geminiResponse;

  const NeumorphicStyledContainer({
    required this.child,
    required this.accuracy,
    required this.geminiProcessing,
    required this.healthData,
    required this.geminiResponse,
  });

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    throw UnimplementedError();
  }
}
