package com.example.healwiz

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
