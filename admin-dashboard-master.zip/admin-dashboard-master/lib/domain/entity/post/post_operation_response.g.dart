// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'post_operation_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_PostOperationResponse _$$_PostOperationResponseFromJson(
        Map<String, dynamic> json) =>
    _$_PostOperationResponse(
      status: json['status'] as bool,
      message: json['message'] as String,
    );

Map<String, dynamic> _$$_PostOperationResponseToJson(
        _$_PostOperationResponse instance) =>
    <String, dynamic>{
      'status': instance.status,
      'message': instance.message,
    };
