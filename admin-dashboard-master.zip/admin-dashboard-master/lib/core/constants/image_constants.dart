class ImageConstants {
  ImageConstants._();
  static const String appLogo = 'assets/images/app_logo.png';
  static const String companyLogo = 'assets/images/company_logo.png';
}