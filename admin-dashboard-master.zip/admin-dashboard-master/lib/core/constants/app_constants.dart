const kSplashDurationInSeconds = 3;
//const kBaseUrl = "http://www.appsdreamers.xyz/api/v1";
const kBaseUrl = "https://private-2d1535-admindashboard4.apiary-mock.com";
const kConnectionTimeoutInMilis = 50000;
const kEmptyString = "";
const kDateFormat = "yyyy-MM-dd'";
const kLeftMenuWidth = 200.0;
